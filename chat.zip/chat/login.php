<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$db = "chat";
//connection to db
$conn = mysqli_connect($host,$user,$pass,$db);

if(isset($_REQUEST['submit']))
{
    $usr = $_REQUEST['user'];
    $psd = $_REQUEST['pass'];

    $sql = "select * from user where gmail = '".$usr."' AND pin = '".$psd."' ";
    $res = mysqli_query($conn,$sql);

    if(mysqli_num_rows($res)==1){
    	 $row=mysqli_fetch_assoc($res);
 //set user is logined     
        $_SESSION['login'] = 1;
// already on index so remove from here this session 
      // $_SESSION['record'] = 0;
//set name of user      
        $_SESSION['name'] = $row['name'];
// sender id assign to var
  	   $_SESSION['sender_id'] = $row['id'];
      // check by credential if admin or not
      //doing this for static testing later change
     //  if($usr=='admin'){
     //  	$_SESSION['admin'] = 0;
     //  }
  	  // else
     //  {
     //  	$_SESSION['student_id'] = $row['id'];       
     //  }
      header("location:index.php");
    }else
    {
      echo "not matched";
    }
}
?>
<form>

	<h1>login</h1>
	<input type="text" name="user" placeholder="username"><br><br>
	<input type="password" name="pass" placeholder="password"><br><br>
	<input type="submit" name="submit" value="login">

</form>