<?php
session_start();
// Sare record ek hi bar fetch hoke aane chaiye chat open kerne per
$_SESSION['one_time'] = 0;
/*   jab user page refesh kerde
    tho new msg fetch kerne ke liye old record count ko 
    0 taki sare record fetch kerke la ske */ 
$_SESSION['record']=0;

if($_SESSION['login']!=1)
  header('location:login.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Chat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@500&display=swap" rel="stylesheet"> 

  <link rel="stylesheet" href="style.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
    
  </style>
</head>
<body>
  <!-- search contacts -->
<div class="bg-secondary" id="main_parent_div" style="overflow-x: hidden;overflow-y:scroll;min-height:0px;max-height:400px;width: 300px;position: absolute;z-index: 100;top:170px;left:20%;" onclick="transfer_contact_profile(event);">
  <div class="row justify-content-center" id="parent_div" style="display: none;">
    
  </div>
</div>
<!-- ============================================================ -->
<!-- search end -->
<!-- ================================================================== -->
<div class="container mt-5">
    <div class="row justify-content-center mt-4">
      <!-- ===================================================================== -->
      <!-- ==================chat view =====================================-->
      <!-- ================================================================-->
      <div class="col-12" >
           <div class="row justify-content-between position-relative">
            <!-- ======================================= -->
              <!-- sender user Profile-->
              <!-- ======================================== -->
            <div class="col-4 chat-row" >
              <div class="row">


                      <div class="col-12 bg-dark d-flex" style="height: 10vh;">
                            <!-- ============= Sender Or User profile ======================= -->
                            <div class="sender_pic" style=" background-image: url(https://www.wallpapertip.com/wmimgs/30-308464_cool-profile-pictures-1080p.jpg);"></div>
                            <h5 style="color:#fff;margin:18px 0px 0px 10px;"><?php echo $_SESSION['name'];?></h5>
                            <!-- sender id ====================-->
                            <i style="color: #fff;font-size: 24px;position: absolute;right: 15px;top: 18px;" class="fa fa-ellipsis-v"></i>
                            <input type="hidden" value="<?php echo $_SESSION['sender_id'];?>" id="sid">      
                      </div>
                

                      <!-- =============================================== -->
                      <!-- ===========search Box ==================== -->
                      <!-- ================================================== -->
                      <div class="col-12 bg-light d-flex" style="height: 7vh;margin:10px 0px;">
                          <input type="text" id="search" name="srch" placeholder="Search" onkeyup="get_search_result();">  
                      </div>
              
                      <!-- ======================================================= -->
                      <!-- Sender Contacts -->
                      <!-- ======================================================== -->
                      <div class="col-12" style="height:60vh;overflow-y:scroll !important;">
                          <div class="row" id="for_get_values" onclick="transfer_user_to_chat_profile(event);">
                            <!-- ================================================ -->

                           

                              <!-- ================================================ -->
                            <!-- ===============Contact start========================= -->
                              <!--<div name="3" class="col-12 d-flex bg-light" id="contact__short_profie"  style="cursor:pointer;height: 65px;border-bottom: 1px solid #000;">
                                    
                                    <div class="contact_pic" name="3" style="background-image: url(https://www.wallpapertip.com/wmimgs/5-56933_profile-picture-for-messi.jpg);">
                                         <div class="online"></div>
                                    </div>
                                    <h5 name="3" style="margin:18px 0px 0px 10px;" id="3contact_name">Brijesh</h5>
                                    
                                    <input name="3" type="hidden" value="3" id="3contact_id">
                              </div>-->                              
                              <!-- ============================================== -->
                              <!-- ==========Contact end ======================== -->                            




                          </div>
                      </div>
                 </div>
            </div>
            <!-- ======================================= -->
              <!-- sender user Profile End-->
              <!-- ======================================== -->
            <!-- ***************************************************** -->
                <div class="col-7" id="chat-row_pre" >
                    <h2>Select a chat to start messaging</h2>
                </div>
                <div class="col-7" id="chat-row" style="display: none;">
                  <!-- ========================================================= -->
                  <!-- Current Chat View -->
                  <!-- ========================================================= -->
                  <div class="row">
                      <div class="col-12 bg-dark d-flex" id="current_chat" style="height: 65px;">
                            <!-- user pic -->
                            <div class="receiver_pic" style="background-image: url(https://www.wallpapertip.com/wmimgs/5-56933_profile-picture-for-messi.jpg);">
                              
                            </div>
                            <h5 id="rec_name">Receiver User</h5>
                            <input type="hidden" value="" id="rec_id">      
                      </div>
                  </div>
                  <!-- ===================================================== -->
                    <!-- chat box -->
                    <!-- -=========================================== -->
                    <div id="chat-box" class="pt-1">
                      
                    </div>
                    <!-- =============================================== -->
                    <!-- send msg to receiver -->
                    <!-- =============================================== -->
                    <div id="inp-chat">
                      <input type="text" id="sender_msg" name="msg" placeholder="Type here">
                      <input type="submit" name="submit" value="SEND" id="msg_btn" style="">
                    </div>
                </div>
            </div>
      </div>
    </div>
</div>

 <script type = "text/javascript" language = "javascript">
//==========================================================================================  
//===================================== Display Contacts ================================  
//========================================================================================== 
function display_contact()
{

  let user_id = document.getElementById('sid').value;

  var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var myObj = JSON.parse(this.responseText);
         
         show_contacts(myObj);

      }
    };
// -------------------------------------------
    function show_contacts(obj)
    {
      /*
                              <div  class="" id=""  style="">
                                
                                    <div class="contact_pic" name="3" style="">
                             
                                          <div class="online"></div>
                             
                                    </div>
                             
                                    <h5 name="3" style="margin:18px 0px 0px 10px;" id="3contact_name">Brijesh</h5>
                  
                                    <input name="3" type="hidden" value="3" id="3contact_id">
                              </div>                              
*/
let parent_div = document.getElementById('for_get_values');
      for(var i=0;i<Object.keys(obj).length;i++){

                    
                    var a= obj[i].contact_id;
                    var b= obj[i].name;
                    var c= obj[i].valid_status;
                    var d= obj[i].active_status;
                  
                       var main_div = document.createElement("div");
                       main_div.style="cursor:pointer;height: 65px;border-bottom: 1px solid #000;";
                       main_div.setAttribute("class", "col-12 d-flex bg-light");
                       main_div.setAttribute("id", "contact__short_profie");
                       main_div.setAttribute("name", a);

                       var first_div = document.createElement("div");
                       first_div.style="background-image: url(https://www.wallpapertip.com/wmimgs/5-56933_profile-picture-for-messi.jpg);";
                       first_div.setAttribute("class", "contact_pic");
                       first_div.setAttribute("name", a);

                       var first_div_child = document.createElement("div");
                       first_div_child.setAttribute("class", "online");
                       first_div_child.setAttribute("name", a);
                
                        var first_h5 = document.createElement("h5");
                       first_h5.style="margin:18px 0px 0px 10px;";
                       first_h5.setAttribute("name", a);
                       first_h5.innerHTML=b;
                       let id_name = a+'contact_name';
                       first_h5.setAttribute("id",id_name);

                  
                       var first_inp = document.createElement("input");
                       first_inp.setAttribute("name", a); 
                       first_inp.setAttribute("type", "hidden"); 
                       first_inp.setAttribute("value", a);
                       let id = a+'contact_id'; 
                       first_inp.setAttribute("id", id); 
                      
                      parent_div.appendChild(main_div);
                      main_div.appendChild(first_div);
                          first_div.appendChild(first_div_child);
                      main_div.appendChild(first_h5);
                      main_div.appendChild(first_inp);
                           
      }
    }
// ----------------------------------------------
 xmlhttp.open("GET", "api/get_contact.php?user_id="+user_id, true);
      xmlhttp.send();

} 

display_contact();
//===========================================================================================
//==================== Save The Contact To DB==============================================
//===========================================================================================
function transfer_contact_profile(event){
  let user_id = document.getElementById('sid').value;
  let contact_id = event.target.getAttribute('name');

   $.ajax({
                            url:'api/save_contact.php',
                            data:{user_id:user_id,contact_id:contact_id},
                            success: function(response)
                            {

                            }
                      });
                      

}
//===========================================================================================
//=======================================Set the values of Receiver==========================
//============================Change the chat for according to user contact==================
//===========================================================================================

  function transfer_user_to_chat_profile(event){
    
      //refresh for new msg in every 3 sec
          setInterval(function(){
                       responsetxt(0,0);
          },3000);
          //swap the chat
    var count_var,i=1;

          //method is time consuming pls optimize
    
          function removechat_onswap(){

                var list = document.getElementById("chat-box");
                count_var = document.getElementById("chat-box").childElementCount;
                 
                 if(count_var==0){
                      clearInterval(func);
                      responsetxt(1,1);
                  }

                 for(let i=0;i<count_var;i++){
                    list.removeChild(list.childNodes[i]);
                  }
            }

      var func = setInterval(removechat_onswap,10);
    //===================================================
    //Remove the prview
    document.getElementById('chat-row_pre').style="display:none";
    document.getElementById('chat-row').style="display:block";
    //get the name and concat it with static name of id's then 
    let value = event.target.getAttribute('name');
    let id_name = value+'contact_name';
    let id = value+'contact_id';

    
    //get the contact control
    document.getElementById('chat-row_pre').style="display:none";
    document.getElementById('chat-row').style="display:block";
    let contact_id = document.getElementById(id);
    let contact_name = document.getElementById(id_name);
    //get the control of current chat profile (receiver user)
    let receiver_id = document.getElementById("rec_id");
    let receiver_name = document.getElementById("rec_name"); 
    //now set the values
    receiver_id.value = `${contact_id.value}`;
    receiver_name.innerHTML = contact_name.innerHTML;

    
  }
                              

       //*******************************************************
       // send the msg to save
       //********************************************************
        
            $('#msg_btn').click(function(){
                
                //bhej ne wale ki id
                var sid=document.getElementById('sid').value;
                //lene wale ki id 
                var rid=document.getElementById('rec_id').value;  
                // sandesh
                var usermsg = $('#sender_msg').val();
                $('#sender_msg').val(null);

                $.ajax({
                            url:'api/savemsg.php',
                            data:{msg:usermsg,sid:sid,rid:rid},
                            success: function(response)
                            {
                              // msg sented then fetch the new msg
                                responsetxt(0,0);        
                            }
                      });
                      
                      $('#chat-box').scrollTop($('#chat-box').height());

            });
       
       // ******************************************************
       //  render the mesage
       // ******************************************************
var control_of_chat_box = document.getElementById('chat-box');

function responsetxt(fetch_once_more,set_record_zero) 
{
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var myObj = JSON.parse(this.responseText);
         set(myObj);
      }
    };
// ---------------------------------------------------------------------------------------------
        function set(obj){
          
          let no_of_rec = Object.keys(obj).length;
          console.log("No of records = "+Object.keys(obj).length);

              for(var i=0;i<Object.keys(obj).length;i++){
                    var a= obj[i].sender;
                    var b= obj[i].receiver;
                    var c= obj[i].msg;

                    if(a==sid){
                      var sender_div = document.createElement("div");
                            var sender_p = document.createElement("p");

                      sender_div.style="width:100%;height:50px;";
                      control_of_chat_box.appendChild(sender_div);
                            
                            sender_p.setAttribute("class", "sender_msg_sty");                    
                            
                      
                            sender_p.innerHTML=c;
                      sender_div.appendChild(sender_p);
                    }else{ 
                      var rec_p = document.createElement("p");
                      var rec_div = document.createElement("div");  

                      rec_div.style="width:100%;height:50px;";
                      control_of_chat_box.appendChild(rec_div);

                                rec_p.setAttribute("class", "rec_msg_sty");  
                      
                                rec_p.innerHTML=c;
                      rec_div.appendChild(rec_p);
                    }
              }
              $('#chat-box').scrollTop($('#chat-box').height());
        }
// -------------------------------------------------------------------------------------------------
            //bhej ne wale ki id
                var sid=document.getElementById('sid').value;
            //lene wale ki id 
                var rid=document.getElementById('rec_id').value;
    xmlhttp.open("GET", "api/getmsg.php?sid="+sid+"&rid="+rid+"&fetch_once_more="+fetch_once_more+"&set_record_zero="+set_record_zero, true);
    xmlhttp.send();
}

// =========================================================================
// ===========================get_search_result===========================
// ======================================================================
function get_search_result(){
console.log("one");
    let query = document.getElementById('search').value;
    let main_parent_div = document.getElementById('main_parent_div');
     let parent_div_sec = document.getElementById('parent_div'); 
    // =========================================================
        parent_div_sec.remove();
        
        var p_div = document.createElement("div");
        p_div.style="display:none";
        p_div.setAttribute("class", "row justify-content-center");
        p_div.setAttribute("id", "parent_div");

        main_parent_div.appendChild(p_div);
    // =========================================================
    let parent_div = document.getElementById('parent_div');
    parent_div.style="display:block";
console.log("two");

       var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var myObj = JSON.parse(this.responseText);

         show_res(myObj);
      }
    };
// --------------------------------------------------------------------
        function show_res(obj){
          
              for(var i=0;i<Object.keys(obj).length;i++){
                    var a= obj[i].id;
                    var b= obj[i].name;
                    console.log(b);

                       var main_div = document.createElement("div");
                       main_div.style="margin-left:11px;border-bottom:1px solid #000;cursor:pointer;height: 50px;position: relative;";
                       main_div.setAttribute("class", "col-11 d-flex bg-dark");
                       main_div.setAttribute("name", a);

                       var first_div = document.createElement("div");
                       first_div.style="background-image: url(https://www.wallpapertip.com/wmimgs/5-56933_profile-picture-for-messi.jpg);";
                       first_div.setAttribute("class", "srch_contact_pic");
                       first_div.setAttribute("name", a);

                       var first_div_child = document.createElement("div");
                       first_div_child.setAttribute("class", "online");
                       first_div_child.setAttribute("name", a);
                
                        var first_h5 = document.createElement("h5");
                       first_h5.style="margin:10px 0px 0px 10px;color:#fff;";
                       first_h5.setAttribute("name", a);
                       first_h5.innerHTML=b;
                       let id_name = a+'contact_name';
                       first_h5.setAttribute("id",id_name);

                       var first_i = document.createElement("i");
                       first_i.style="color:tomato;right:10px;font-size: 24px;position:absolute;top: 10px;";
                       first_i.setAttribute("class", "fa fa-user-plus");
                       first_i.setAttribute("name", a);

                       var first_inp = document.createElement("input");
                       first_inp.setAttribute("name", a); 
                       first_inp.setAttribute("type", "hidden"); 
                       first_inp.setAttribute("value", a);
                       let id = a+'contact_id'; 
                       first_inp.setAttribute("id", id); 
                      
                      parent_div.appendChild(main_div);
                            main_div.appendChild(first_div);
                                    first_div.appendChild(first_div_child);
                            main_div.appendChild(first_h5);
                            main_div.appendChild(first_i);
                            main_div.appendChild(first_inp);
              }
        }
        
    if(query.trim()!="")
    {
      xmlhttp.open("GET", "api/search_record.php?srch="+query, true);
      xmlhttp.send();
    }
    //------------------------------------------------------------------------------- 
}

// ==========================================================
// =================== remove search result on click anywhere ===========================
document.addEventListener("click",function(){
      let parent_div = document.getElementById('parent_div');
      parent_div.style="display:none";
});
// ==========================================================
// ==========================================================
</script>

</body>
</html>
