<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "chat";

$conn = mysqli_connect($host,$user,$pass,$db);
$row =array();

if(isset($_REQUEST['user_id'])){
	$query = $_REQUEST['user_id'];

	$sql = "SELECT uc.contact_id,uc.valid_status,uc.active_status,u.name FROM user_contact as uc 
			inner join user as u 
			on uc.contact_id = u.id and uc.user_id=$query";
// echo $sql;
	$result = mysqli_query($conn,$sql);
        			if(mysqli_num_rows($result)>0){
						while($rows = mysqli_fetch_assoc($result))
						{
							$row[] = $rows;
						}
					}
								echo json_encode($row);

}

?>