<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "chat";

$conn = mysqli_connect($host,$user,$pass,$db);

$a = 'tets';
$b =" ' or id = '1";
$sql = "SELECT * from user where gmail='$a' AND pin=' ' or '' = '' ";
$sql2 = "SELECT * from user where gmail='$a' AND pin='$b' ";
echo $sql;
echo '<br>--------------/>'.$sql2;

// $x = "SELECT * FROM `user` WHERE gmail='k' AND pin='k' OR 1=1 ";

mysqli_query($conn,$sql2);

if(mysqli_num_rows(mysqli_query($conn,$sql2))>0)
{	
	echo '<br>True';
	echo "<br>No Of Records ".mysqli_num_rows(mysqli_query($conn,$sql2));
}else{
	echo "<br> False";
}
?>