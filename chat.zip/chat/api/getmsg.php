 <?php
session_start();

$sid = $_REQUEST['sid'];
$rid = $_REQUEST['rid'];
$fetch_once_more = $_REQUEST['fetch_once_more'];


        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "chat";
        $conn = mysqli_connect($host,$user,$pass,$db);

		$row =array();
        
        $getbox ="select * from user_message where sender=$sid AND receiver=$rid OR sender=$rid AND receiver=$sid ";
        $run = mysqli_query($conn,$getbox);    

        	// set the record count zero once again zero when they change the chats 
        	if($_REQUEST['set_record_zero'] == 1 )
			{
				$_SESSION['record'] = 0;	 
			}   
			//store record count for first time
			if($_SESSION['record'] == 0 )
			{
				$_SESSION['record'] = mysqli_num_rows($run);	 
			}
			//if record - count > 0 means new record are there then fetch only new
			if((mysqli_num_rows($run) - $_SESSION['record']) > 0)
			{
				// diff
				$diff = mysqli_num_rows($run) - $_SESSION['record'];

				$sql = "SELECT * FROM `user_message` WHERE sender=$sid AND receiver=$rid OR sender=$rid AND receiver=$sid ORDER BY id DESC LIMIT $diff ";
        		$result = mysqli_query($conn,$sql);
        			if(mysqli_num_rows($result)>0){
						while($rows = mysqli_fetch_assoc($result))
						{
							$row[] = $rows;
						}
					}

			}
			//fetch record for first time shown to user old messages
			if($_SESSION['one_time']==0 || $fetch_once_more==1)
			{
				$_SESSION['one_time']=1;
				 if(mysqli_num_rows($run)>0){
					while($rows = mysqli_fetch_assoc($run))
					{
						$row[] = $rows;
					}
				}
			}
			//update record count for count the new msges
			if($_SESSION['record'] < mysqli_num_rows($run))
			{
				$_SESSION['record'] = mysqli_num_rows($run);	 
			}

			echo json_encode($row);
		?>
    
