<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "chat";

$conn = mysqli_connect($host,$user,$pass,$db);
$row =array();

if(isset($_REQUEST['srch'])){
	$query = $_REQUEST['srch'];
	$sql = "SELECT id,name FROM user WHERE name LIKE '%$query%'";

	$result = mysqli_query($conn,$sql);
        			if(mysqli_num_rows($result)>0){
						while($rows = mysqli_fetch_assoc($result))
						{
							$row[] = $rows;
						}
					}
								echo json_encode($row);

}

?>