<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "chat";

$conn = mysqli_connect($host,$user,$pass,$db);

if(isset($_REQUEST['user_id'])){
	$sender_id = $_REQUEST['user_id'];
	$receiver_id = $_REQUEST['contact_id'];
	// 0 = true
	//1 = false

	//chk already exits or not
	
	$sql="INSERT INTO `user_contact` (user_id,contact_id,valid_status,active_status)
			 VALUES ($sender_id, $receiver_id,0,1)";
			$run=mysqli_query($conn,$sql);

}

?>