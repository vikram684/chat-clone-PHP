<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "chat";

$conn = mysqli_connect($host,$user,$pass,$db);

if(isset($_REQUEST['msg'])){

	$msg = $_REQUEST['msg'];
	$sender_id = $_REQUEST['sid'];
	$receiver_id = $_REQUEST['rid'];
	
	$sql="INSERT INTO `user_message` (`sender`, `receiver`, `msg`)
			 VALUES ($sender_id, $receiver_id, '$msg')";
			$run=mysqli_query($conn,$sql);

}

?>